const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// ✅ Serve HTML and other static files from the "public" folder
app.use(express.static(path.join(__dirname, 'public')));

// ✅ Connect to MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Chinmayp@2006',
  database: 'doctor_finder'
});

db.connect(err => {
  if (err) throw err;
  console.log("✅ MySQL connected...");
});

// ✅ LOGIN route
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  console.log("🔐 Login attempt:", username);

  const sql = 'SELECT * FROM users WHERE username = ? AND password = ?';
  db.query(sql, [username, password], (err, results) => {
    if (err) {
      console.error("❌ Login DB error:", err);
      return res.status(500).json({ success: false, message: "Database error" });
    }

    if (results.length > 0) {
      console.log("✅ Login success:", username);
      res.json({ success: true });
    } else {
      console.log("❌ Invalid login:", username);
      res.json({ success: false, message: "Invalid credentials" });
    }
  });
});

// ✅ SIGNUP route
app.post('/signup', (req, res) => {
  const { username, password } = req.body;
  console.log("🆕 Signup attempt:", username);

  if (!username || !password) {
    return res.status(400).json({ success: false, message: "Username and password required." });
  }

  db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
    if (err) {
      console.error("❌ DB error checking user:", err);
      return res.status(500).json({ success: false, message: "Database error" });
    }

    if (results.length > 0) {
      console.log("❌ Username already exists:", username);
      return res.json({ success: false, message: "Username already exists" });
    }

    db.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, password], (insertErr) => {
      if (insertErr) {
        console.error("❌ Insert error:", insertErr);
        return res.status(500).json({ success: false, message: "Signup failed" });
      }

      console.log("✅ User registered:", username);
      res.json({ success: true });
    });
  });
});

// ✅ Start server
app.listen(3000, () => {
  console.log('🚀 Server running on http://localhost:3000');
});
// ✅ GET all doctors
app.get('/api/doctors', (req, res) => {
  const sql = 'SELECT * FROM doctors';
  db.query(sql, (err, results) => {
    if (err) {
      console.error("❌ Failed to get doctors:", err);
      return res.status(500).json({ success: false, message: "Database error" });
    }
    res.json({ success: true, doctors: results });
  });
});
app.post('/register-doctor', (req, res) => {
  const { name, specialty, location, qualification, phone } = req.body;

  if (!name || !specialty || !location || !qualification || !phone) {
    return res.status(400).json({ success: false, message: "All fields are required." });
  }

  const sql = 'INSERT INTO doctors (name, specialty, location, qualification, phone) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [name, specialty, location, qualification, phone], (err) => {
    if (err) {
      console.error("❌ DB Insert Error:", err);
      return res.status(500).json({ success: false, message: "Database error" });
    }

    console.log("✅ Doctor registered:", name);
    res.json({ success: true });
  });
});


